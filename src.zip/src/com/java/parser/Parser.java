package com.java.parser;

public interface Parser
{
	public void parse();
}
