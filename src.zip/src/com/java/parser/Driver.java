package com.java.parser;
/**
 * 
 */

/**
 * @author timmcclintock
 *
 */
public class Driver
{

	/**
	 * @param args
	 */
	public static void main ( String[] args )
	{
		CPPParser cppParser = new CPPParser();
		System.out.println(cppParser.getLineList());
	}

}
